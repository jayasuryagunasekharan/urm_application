export const OfficerDashboardData = [
    {
        Race: 'White',
        Candidates: 50,
    },
    {
        Race: 'Black or African American',
        Candidates: 30,
    },
    {
        Race: 'American Indian or Alaska Native',
        Candidates: 10,
    },
    {
        Race: 'Asian',
        Candidates: 20,
    },
    {
        Race: 'Native Hawaiian or Other Pacific Islander',
        Candidates: 5,
    }
]
